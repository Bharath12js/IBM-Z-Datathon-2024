from flask import Flask, request, render_template, redirect, url_for, send_from_directory
from werkzeug.utils import secure_filename
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from PIL import Image
import os

# Initialize the Flask app
app = Flask(__name__)

# Load the model
model = load_model('C:/Users/Bharath/Downloads/IBM Z Datathon/CNN31_model.h5')

# Define the class indices
class_indices = {0: 'Mild_Demented', 1: 'Moderate_Demented', 2: 'Non_Demented', 3: 'Very_Mild_Demented'}

# Create an upload folder
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Define a route for the home page
@app.route('/')
def index():
    return render_template('index.html')

# Define a route for the prediction
@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return redirect(request.url)

    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)

    if file:
        # Save the file to the upload folder
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        # Open the image using PIL and convert it to grayscale
        img = Image.open(filepath).convert('L')  # 'L' mode is for grayscale

        # Resize the image
        img = img.resize((128, 128))  # Resize to the expected input size

        # Convert the image to an array
        img_array = image.img_to_array(img)

        # Expand dimensions to match the model's input shape (1, 128, 128, 1)
        img_array = np.expand_dims(img_array, axis=0)
        img_array = np.expand_dims(img_array, axis=-1)

        # Normalize the image
        img_array /= 255.0

        # Make a prediction
        predictions = model.predict(img_array)
        predicted_index = np.argmax(predictions, axis=1)[0]
        predicted_class = class_indices[predicted_index]
        confidence = predictions[0][predicted_index] * 100

        # Return the prediction result
        return render_template('result.html', prediction=predicted_class, confidence=confidence, filename=filename)

# Define a route to serve images from the uploads folder
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
